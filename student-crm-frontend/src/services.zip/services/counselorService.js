import axios from "axios";

const API_URL = "http://localhost:8082/users";

export const getCounselors = () => {
    return axios.get(`${API_URL}/counselors`);
};