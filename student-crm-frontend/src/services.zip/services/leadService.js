import api from "../api/axios";

// Get All Leads
export const getAllLeads = () => {
    return api.get("/lead/all");
};