import api from "../api/axios";

export const getDashboardStats = async () => {
    return await api.get("/dashboard/stats");
};

export const getRecentAdmissions = async () => {
    return await api.get("/dashboard/recent-admissions");
};