import axios from "axios";

const API_URL = "http://localhost:8082/course";

// Get All Courses
export const getAllCourses = () => {
    return axios.get(`${API_URL}/all`);
};

// Save Course
export const addCourse = (course) => {
    return axios.post(`${API_URL}/save`, course);
};

// Update Course
export const updateCourse = (id, course) => {
    return axios.put(`${API_URL}/update/${id}`, course);
};

// Delete Course
export const deleteCourse = (id) => {
    return axios.delete(`${API_URL}/delete/${id}`);
};

// Search Course
export const searchCourses = (keyword) => {
    return axios.get(`${API_URL}/search?keyword=${keyword}`);
};