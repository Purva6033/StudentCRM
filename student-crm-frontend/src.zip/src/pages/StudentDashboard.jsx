import MainLayout from "../layouts/MainLayout";

function StudentDashboard() {

    const email = localStorage.getItem("email");

    return (

        <MainLayout>

            <div className="container-fluid">

                <div className="mb-4">
                    <h2>Student Dashboard</h2>
                    <p className="text-muted">
                        Welcome, {email}
                    </p>
                </div>

                <div className="card shadow">

                    <div className="card-header">
                        <h5 className="mb-0">My Profile</h5>
                    </div>

                    <div className="card-body">

                        <table className="table">

                            <tbody>

                                <tr>
                                    <th>Student Name</th>
                                    <td>--</td>
                                </tr>

                                <tr>
                                    <th>Student Code</th>
                                    <td>--</td>
                                </tr>

                                <tr>
                                    <th>Course</th>
                                    <td>--</td>
                                </tr>

                                <tr>
                                    <th>Admission Date</th>
                                    <td>--</td>
                                </tr>

                                <tr>
                                    <th>Status</th>
                                    <td>--</td>
                                </tr>

                                <tr>
                                    <th>Counselor</th>
                                    <td>--</td>
                                </tr>

                            </tbody>

                        </table>

                    </div>

                </div>

            </div>

        </MainLayout>

    );

}

export default StudentDashboard;