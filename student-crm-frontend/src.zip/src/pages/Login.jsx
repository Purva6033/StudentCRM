import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { FaUserGraduate } from "react-icons/fa";
import { loginUser } from "../services/authService";
import "../styles/login.css";

function Login() {

    const navigate = useNavigate();

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const handleLogin = async () => {

        try {

            const response = await loginUser({
                email: email,
                password: password
            });

            // Store user information
            localStorage.setItem("token", response.data.token);
            localStorage.setItem("email", response.data.email);
            localStorage.setItem("role", response.data.role);

            const role = response.data.role;

            // Redirect based on role
            if (role === "ADMIN") {
                navigate("/dashboard");
            }
            else if (role === "COUNSELOR") {
                navigate("/counselor-dashboard");
            }
            else if (role === "STUDENT") {
                navigate("/student-dashboard");
            }
            else {
                alert("Invalid User Role");
            }

        } catch (error) {

            console.log("Full Error:", error);

            if (error.response) {
                console.log("Response Status:", error.response.status);
                console.log("Response Data:", error.response.data);
                alert(error.response.data);
            }
            else {
                alert("Login Failed");
            }
        }
    };

    return (

        <div className="login-page">

            <div className="card login-card">

                <div className="text-center mb-4">

                    <FaUserGraduate className="login-icon" />

                    <h1 className="login-title">
                        Student CRM
                    </h1>

                    <p className="text-secondary mb-1">
                        Spring Boot + React
                    </p>

                    <p className="text-muted">
                        Student Admission Management System
                    </p>

                </div>

                <hr />

                <div className="mb-3">

                    <label className="form-label">
                        Email
                    </label>

                    <input
                        type="email"
                        className="form-control"
                        placeholder="Enter Email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />

                </div>

                <div className="mb-4">

                    <label className="form-label">
                        Password
                    </label>

                    <input
                        type="password"
                        className="form-control"
                        placeholder="Enter Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />

                </div>

                <button
                    className="btn btn-primary login-btn"
                    onClick={handleLogin}
                >
                    Login
                </button>

            </div>

        </div>

    );
}

export default Login;