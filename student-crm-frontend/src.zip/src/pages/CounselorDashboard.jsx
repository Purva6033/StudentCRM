import MainLayout from "../layouts/MainLayout";

function CounselorDashboard() {

    const email = localStorage.getItem("email");

    return (

        <MainLayout>

            <div className="container-fluid">

                <div className="mb-4">
                    <h2>Counselor Dashboard</h2>
                    <p className="text-muted">
                        Welcome, {email}
                    </p>
                </div>

                <div className="row">

                    <div className="col-md-4 mb-4">
                        <div className="card shadow border-0 bg-primary text-white">
                            <div className="card-body text-center">
                                <h3>📋</h3>
                                <h5>My Leads</h5>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-4 mb-4">
                        <div className="card shadow border-0 bg-success text-white">
                            <div className="card-body text-center">
                                <h3>💰</h3>
                                <h5>My Admissions</h5>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-4 mb-4">
                        <div className="card shadow border-0 bg-warning text-white">
                            <div className="card-body text-center">
                                <h3>📞</h3>
                                <h5>My Follow Ups</h5>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </MainLayout>

    );
}

export default CounselorDashboard;