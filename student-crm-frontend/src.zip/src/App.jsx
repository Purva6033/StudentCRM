import { BrowserRouter, Routes, Route } from "react-router-dom";

import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import CounselorDashboard from "./pages/CounselorDashboard";
import StudentDashboard from "./pages/StudentDashboard";
import Counselors from "./pages/Counselors";
import Students from "./pages/Students";
import Admissions from "./pages/Admissions";
import Leads from "./pages/Leads";
import Courses from "./pages/Courses";

import FollowUps from "./pages/FollowUps";

import ProtectedRoute from "./components/ProtectedRoute";

function App() {

  return (

    <BrowserRouter>

      <Routes>

        {/* Login */}
        <Route path="/" element={<Login />} />

        {/* Admin Dashboard */}
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />

        {/* Counselor Dashboard */}
        <Route
          path="/counselor-dashboard"
          element={
            <ProtectedRoute>
              <CounselorDashboard />
            </ProtectedRoute>
          }
        />

        {/* Student Dashboard */}
        <Route
          path="/student-dashboard"
          element={
            <ProtectedRoute>
              <StudentDashboard />
            </ProtectedRoute>
          }
        />

        {/* Modules */}

        <Route
          path="/students"
          element={
            <ProtectedRoute>
              <Students />
            </ProtectedRoute>
          }
        />

        <Route
          path="/leads"
          element={
            <ProtectedRoute>
              <Leads />
            </ProtectedRoute>
          }
        />


        <Route
          path="/courses"
          element={
            <ProtectedRoute>
              <Courses />
            </ProtectedRoute>
          }
        />

        <Route
          path="/admissions"
          element={
            <ProtectedRoute>
              <Admissions />
            </ProtectedRoute>
          }
        />

        <Route
          path="/followups"
          element={
            <ProtectedRoute>
              <FollowUps />
            </ProtectedRoute>
          }
        />

        <Route
          path="/counselors"
          element={
            <ProtectedRoute>
              <Counselors />
            </ProtectedRoute>
          }
        />
      </Routes>

    </BrowserRouter>

  );

}

export default App;