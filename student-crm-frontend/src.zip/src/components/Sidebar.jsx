import { NavLink } from "react-router-dom";

function Sidebar() {

    const role = localStorage.getItem("role");

    return (

        <div
            className="bg-dark text-white"
            style={{
                width: "250px",
                minHeight: "100vh"
            }}
        >

            <h3 className="text-center py-4 border-bottom">
                Student CRM
            </h3>

            <div className="nav flex-column p-3">

                {/* Dashboard */}

                <NavLink className="nav-link text-white mb-2"
                    to={
                        role === "ADMIN"
                            ? "/dashboard"
                            : role === "COUNSELOR"
                                ? "/counselor-dashboard"
                                : "/student-dashboard"
                    }
                >
                    📊 Dashboard
                </NavLink>

                {/* Admin Only */}

                {role === "ADMIN" && (
                    <>
                        <NavLink className="nav-link text-white mb-2" to="/students">
                            👨‍🎓 Students
                        </NavLink>

                        <NavLink className="nav-link text-white mb-2" to="/leads">
                            📋 Leads
                        </NavLink>

                        <NavLink className="nav-link text-white mb-2" to="/courses">
                            📚 Courses
                        </NavLink>

                        <NavLink className="nav-link text-white mb-2" to="/admissions">
                            📝 Admissions
                        </NavLink>

                        <NavLink className="nav-link text-white mb-2" to="/followups">
                            📞 Follow Ups
                        </NavLink>

                        <Nav.Link as={Link} to="/counselors">
                            Counselors
                        </Nav.Link>
                    </>
                )}

                {/* Counselor Only */}

                {role === "COUNSELOR" && (
                    <>
                        <NavLink className="nav-link text-white mb-2" to="/leads">
                            📋 Leads
                        </NavLink>

                        <NavLink className="nav-link text-white mb-2" to="/admissions">
                            📝 Admissions
                        </NavLink>

                        <NavLink className="nav-link text-white mb-2" to="/followups">
                            📞 Follow Ups
                        </NavLink>
                    </>
                )}

                {/* Student Only */}

                {role === "STUDENT" && (
                    <>
                        <NavLink className="nav-link text-white mb-2" to="/student-dashboard">
                            👤 My Profile
                        </NavLink>
                    </>
                )}

                <hr />

                <button
                    className="btn btn-danger mt-2"
                    onClick={() => {
                        localStorage.clear();
                        window.location.href = "/";
                    }}
                >
                    Logout
                </button>

            </div>

        </div>

    );
}

export default Sidebar;