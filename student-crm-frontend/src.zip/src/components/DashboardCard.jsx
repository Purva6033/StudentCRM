function DashboardCard({ title, count, icon, color }) {
    return (
        <div className="col-lg-4 col-md-6 col-sm-6 mb-4">
            <div className={`card border-0 shadow ${color}`}>
                <div className="card-body text-center text-white">

                    <h1>{icon}</h1>

                    <h5>{title}</h5>

                    <h2>{count}</h2>

                </div>
            </div>
        </div>
    );
}

export default DashboardCard;